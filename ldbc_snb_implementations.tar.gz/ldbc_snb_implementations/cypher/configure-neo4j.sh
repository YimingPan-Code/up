#!/bin/bash

$NEO4J_HOME/bin/neo4j-admin set-initial-password admin

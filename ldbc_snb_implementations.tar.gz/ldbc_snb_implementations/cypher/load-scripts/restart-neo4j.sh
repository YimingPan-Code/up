#!/bin/bash

$NEO4J_HOME/bin/neo4j restart

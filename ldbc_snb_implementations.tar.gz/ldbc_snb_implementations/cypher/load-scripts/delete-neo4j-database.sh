#!/bin/bash

$NEO4J_HOME/bin/neo4j stop
rm -rf $NEO4J_DB_DIR

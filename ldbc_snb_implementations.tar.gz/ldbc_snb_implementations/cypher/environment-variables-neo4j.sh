#!/bin/bash

export NEO4J_HOME=`pwd`/neo4j-server
export NEO4J_DB_DIR=`pwd`/neo4j-server/data/databases/graph.db

insert into forum_person (
    fp_forumid
  , fp_personid
  , fp_joindate
)
values
(
    :forumId
  , :personId
  , :joinDate
);

insert into person_company (
    pc_personid
  , pc_organisationid
  , pc_workfrom
)
values
(
    :personId
  , :organizationId
  , :worksFromYear
);

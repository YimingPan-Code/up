insert into message_tag (
    mt_messageid
  , mt_tagid
)
values
(
    :postId
  , :tagId
);

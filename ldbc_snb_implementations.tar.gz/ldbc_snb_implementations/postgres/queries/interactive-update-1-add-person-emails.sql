insert into person_email (
    pe_personid
  , pe_email
)
values
(
    :personId
  , :email
);

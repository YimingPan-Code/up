insert into person_language (
    plang_personid
  , plang_language
)
values
(
    :personId
  , :language
);

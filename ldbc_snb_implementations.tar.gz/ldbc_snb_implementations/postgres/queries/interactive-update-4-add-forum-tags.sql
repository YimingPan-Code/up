insert into forum_tag (
    ft_forumid
  , ft_tagid
)
values
(
    :forumId
  , :tagId
);

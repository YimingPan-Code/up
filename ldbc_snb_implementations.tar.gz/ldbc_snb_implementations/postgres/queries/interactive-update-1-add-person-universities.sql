insert into person_university (
    pu_personid
  , pu_organisationid
  , pu_classyear
)
values
(
    :personId
  , :organizationId
  , :studiesFromYear
);

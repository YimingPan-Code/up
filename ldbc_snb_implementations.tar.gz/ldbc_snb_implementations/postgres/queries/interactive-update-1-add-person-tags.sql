insert into person_tag (
    pt_personid
  , pt_tagid
)
values
(
    :personId
  , :tagId
);

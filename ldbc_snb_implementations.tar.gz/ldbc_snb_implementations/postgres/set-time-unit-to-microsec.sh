#!/bin/bash

sed -i 's/MILLISECOND/MICROSECOND/' interactive-*.properties
